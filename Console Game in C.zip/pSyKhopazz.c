#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>
#include<time.h>
#include<conio.h>
#define BOARDFPS_WIDTH 40
#define BOARDFPS_HEIGHT 15
#define BOARD_WIDTH 20
#define BOARD_HEIGHT 18
#define ENTER 13
#define ESC 27
#define BACKSPACE 8

//global variables
FILE *userPtr;
FILE *mapPtr;
FILE *weaponPtr;
int countEnemy;
int indexEnemy = 0;
int indexUser = 0;
int indexWeapon = 0;
int flagUser; // Penanda user yang dipakai
char townMapFormat[100][100]; //format town map 
char fpsMap[][50] =	  { "########################################\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"#                                      #\n",
						"########################################\n"};			
typedef struct Crosshair
{
	int x;
	int y;
}Crosshair;
Crosshair crosshair;
typedef struct Weapon{
	int id;
	char name[100];
	int price;
	int damage;
}Weapon;
//structs userlist
typedef struct User{
	int id;
	char username[100];
	char password[100];
	int weaponID;
	int score;
}User;
//struct player movements
typedef struct Player{
	int x;
	int y;
	int health;
}Player;
//struct enemy
typedef struct Enemy{
	int name[100];
	int x;
	int y;
	int health;
	int dead;
}Enemy;
Weapon weapon[100];
Player player;
User user[100];
Enemy enemy[5];
void enemyAnimation(int tempX,int tempY,int *flag,int ammo,int stock);
void homeMenu();
void weaponList();
void printWeaponList();
void showMapRenderUpdate();
void exitGame();
void renderFPSUpdate();
void blacksmithMenu();
void leaderBoard();
void showStatus();
void showFPSStatus(int ammo,int stock);
void saveUserFile();
void gameplayFPS();
void gameplay();
void addEnemy();
int  isSafe(int x,int y);
int isSafeCrosshair(int x,int y);
int randGenerator(int x,int n);
void gotoxy(int x,int y);
void sleep(int time);
void showEnemyStatus(int setVisible,int flag,int damageDeal);
void playerShot(int *flag,int *damageDeal,int *setVisible,int ammo,int stock);
void space(int x);
void registerNewPlayer();
char *encryptedCaesar(char newPassword[]);
char *decryptedCaesar(char newPassword[]);
void splashScreen();
void loginUser();
void loadingMap();
void moveNorth();
void moveSouth();
void moveEast();
void moveWest();
void getDamage();
int checkUser(char name[],char password[]);
void userList();
int main ()
{
	userPtr = fopen("users.txt","r");
	mapPtr = fopen("Map.txt","r");
	weaponPtr = fopen("Weapon.txt","r");
	if(userPtr == NULL){
		printf("Error reading Users files!\n");
		return -1;
	}
	if(mapPtr == NULL){
		printf("Error reading Map files!\n");
		return -1;
	}
	if(weaponPtr == NULL)
	{
		printf("Error reading Weapon files!\n");
		return -1;
	}
	char intro[] = "\tA world where a human's state of mind and the criminal potential of their personality can be quantified.\n\tWhile all sorts of inclinations are recorded and policed, these measured numbers used to judge people's\n\tsouls are commonly called one's... PSYCHO-PASS.";
	char newPlayerQuestion[] = "\tAre you new player (Case Insensitive [Y/N]) ?\n\t";
	char caseNewPlayer;
	userList();//masukkan file user ke struct array
	weaponList();//masukkan file weapon ke struct array
	loadingMap(); // masukkan file map ke dalam char array. 
	addEnemy(); 
	space(15);
	for(int i = 0 ; i < strlen(intro);i ++)
	{
		printf("%c",intro[i]);
		sleep(3500000);
	}
	scanf("[^\n]");
	getchar();
	space(15);
	for(int i = 0 ; i < strlen(newPlayerQuestion) ; i ++)
	{
		printf("%c",newPlayerQuestion[i]);
		sleep(3500000);
	}
	scanf("%c",&caseNewPlayer);
	getchar();
	if(caseNewPlayer == 'y' || caseNewPlayer == 'Y')
	{
		registerNewPlayer();
	}
	splashScreen();
	printf("Press any key to continue.....");
	scanf("[^\n]");
	getchar();
	loginUser();	
	gameplay();
	fclose(userPtr);
	fclose(weaponPtr);
	fclose(mapPtr);
}
void printWeaponList()
{
	for(int i = 0 ; i < indexWeapon ; i ++)
	{
		printf("\t%d. %s [%d point's']\n",i + 1,weapon[i].name,weapon[i].price);
	}
	printf("\t%d. Exit",indexWeapon + 1);
}
void loadingMap()
{
	for(int i  = 0 ; i < BOARD_HEIGHT ; i++)
	{
		fgets(townMapFormat[i],100,mapPtr);
	}
}
void showMapRenderUpdate()
{
	townMapFormat[player.y][player.x] = 2;
	for(int i = 0 ; i < BOARD_HEIGHT ; i ++)
	{
		for(int j = 0 ; j < BOARD_WIDTH ; j ++)
		{
			if(townMapFormat[i][j] == '#')
			{
				printf("\033[0;34m");	
				printf("%c%c",186,186);
			}
			else if(townMapFormat[i][j] == '.'){
				printf("\033[0;33m");
				printf("%c ",townMapFormat[i][j]);
			}
			else if(townMapFormat[i][j] == 'B' ||townMapFormat[i][j] == 'H'){
				printf("\033[0;32m");
				printf("%c ",townMapFormat[i][j]);
			}
			else{
				printf("\033[0m");
				printf("%c ",townMapFormat[i][j]);
			}
		}
		printf("\n");
	}
	printf("\033[0m");
	printf("\npress [w|a|s|d] to move\n");
	printf("[H]:Home\n");
	printf("[B]: Blacksmith");
}
void showStatus()
{
	gotoxy(50,10);
	printf("\033[0;32m");
	printf("User Name: %s",user[flagUser].username);
	gotoxy(50,11);
	printf("\033[0;32m");
	printf("User HP: %d",player.health);
	gotoxy(50,12);
	printf("\033[0;32m");
	printf("User Weapon: %s",weapon[user[flagUser].weaponID].name);
	gotoxy(0,22);
}
void blacksmithMenu()
{
	char input;
	char menu[][100] = {"\t1. Look Weapon\t\t<\n\t2. Exit",
						"\t1. Look Weapon\n\t2. Exit\t\t\t<"};
	int flag = 0;
	int flagWeaponTypes = 0;
	do{
		do
		{
			space(15);
			printf("\tBlacksmith!!\n");
			printf("%s",menu[flag]);
			input = getch();
			if(input == 115)
				flag = 1;
			else if(input == 119)
				flag = 0;
			else if(input == ENTER)
				break;
		}while(1);
		if(flag == 0)
		{
		
			do
			{
				space(15);
				printf("\tWelcome what do you want?\n");
				printWeaponList();
				while(flagWeaponTypes > indexWeapon)
					flagWeaponTypes --;
				while(flagWeaponTypes < 0)
					flagWeaponTypes ++;
				gotoxy(50,16 + flagWeaponTypes);
				printf("<");		
				input = getch();
				if(input == 115)
					flagWeaponTypes ++;
				else if(input == 119)
					flagWeaponTypes --;
				else if(input == ENTER)
					break;		
			}while(1);
			if(weapon[flagWeaponTypes].price > user[flagUser].score){
				gotoxy(8,indexWeapon + 16);
				printf("FAILED NEED MORE POINT!!");
				scanf("[^\n]");
				getchar();
			}
			else{
				user[flagUser].score -= weapon[flagWeaponTypes].price;
				user[flagUser].weaponID = weapon[flagWeaponTypes].id;
			}
			
		}
		else
			return;
	}while(1);
}
void homeMenu()
{
	int flagHomeMenu = 0;
	char ch;
	do
	{
		do{
			space(20);
			printf("\t%s Home!\n",user[flagUser].username);
			printf("\t1. Look Leader Board\n");
			printf("\t2. Save\n");
			printf("\t3. Rest\n");
			printf("\t4. Exit\n");
			while(flagHomeMenu < 0)
				flagHomeMenu ++;
			while(flagHomeMenu > 3)
				flagHomeMenu --;
			gotoxy(50,21 + flagHomeMenu);
			printf("<");
			ch = getch();
			if(ch == 115)
				flagHomeMenu ++;
			else if(ch == 119)
				flagHomeMenu --;
			else if(ch == ENTER)
				break;
		}while(1);
		if(flagHomeMenu == 0)
		{
			leaderBoard();
		}
		else if(flagHomeMenu == 1){
			saveUserFile();
		}
		else if(flagHomeMenu == 2)
		{
			player.health = 100;
			if(user[flagUser].score > 0)
				user[flagUser].score -= 10;
			space(0);
			printf("Rest Success!\n");
			scanf("[^\n]");
			getchar();
		}
		else
			break;
	}while(1);
	
}
void saveUserFile()
{
	userPtr = freopen("users.txt","w",userPtr);
	for(int i = 0 ; i < indexUser ; i ++){
		fprintf(userPtr,"%d#%s#%s#%d#%d\n",user[i].id,user[i].username,encryptedCaesar(user[i].password),user[i].weaponID,user[i].score);
	}
	space(0);
	printf("Success!");
	scanf("[^\n]");
	getchar();
}
int isSafe(int x,int y)
{
	if(townMapFormat[y][x] == '#')
		return -1;
	if(townMapFormat[y][x] == 'B')
	{
		blacksmithMenu();
		return -1;
	}
	if(townMapFormat[y][x] == 'H')
	{
		homeMenu();
		return -1;
	}
	if(townMapFormat[y][x] == ' ')
	{
		space(0);
		scanf("[^\n]");
		getchar();
		gameplayFPS();
		return -1;
	}
	return 1;
		
}
void leaderBoard()
{
	int valid[100] = {0};
	int min;
	int index;
	space(0);
	printf("Leader Board Score\n=======================\n");
	for(int i = 0 ; i < indexUser ; i ++)
	{
		min = 10000000;
		for(int j = 0 ; j < indexUser ; j ++)
		{
			if(user[j].score < min && valid[j] == 0){
				min = user[j].score;
				index = j;
			}
		}
		printf("%s %d\n",user[index].username,user[index].score);
		valid[index] = 1;
	}
	scanf("[^\n]");
	getchar();
}
void weaponList()
{
	while(!feof(weaponPtr))
	{
		fscanf(weaponPtr,"%d%*c%[^#]%*c%d%*c%d\n",&weapon[indexWeapon].id,weapon[indexWeapon].name,&weapon[indexWeapon].price,&weapon[indexWeapon].damage);
		indexWeapon ++;
	}
}
void moveNorth()
{
	if(isSafe(player.x,player.y - 1) == 1){
		player.y -= 1;
		townMapFormat[player.y + 1][player.x] = '.';
	}
	
}
void moveWest()
{
	if(isSafe(player.x - 1,player.y) == 1){
		player.x -= 1;
		townMapFormat[player.y][player.x + 1] = '.';
	}
}
void moveEast()
{
	if(isSafe(player.x + 1 ,player.y) == 1){
		player.x += 1;
		townMapFormat[player.y][player.x - 1] = '.';
	}
}
void moveSouth()
{
	if(isSafe(player.x,player.y + 1) == 1){
		player.y += 1;
		townMapFormat[player.y - 1][player.x] = '.';
	}
}
void exitGame()
{
	char exitTitle[] = "Gaining Experience, Achieving Mystery\n";
	for(int i = 0 ; i < strlen(exitTitle); i ++)
	{
		printf("%c",exitTitle[i]);
		sleep(5500000);
	}
	scanf("[^\n]");
	getchar();
}
void gameplay()
{
	crosshair.x = 28;
	crosshair.y = 5;
	player.x = 12;
	player.y = 12;
	char move;
	player.health = 100;
	while(1)
	{
		system("cls");
		showMapRenderUpdate();
		showStatus();
		printf("\033[0m");
		move = getch();
		if(move == 119)
			moveNorth();
		else if(move == 97)
			moveWest();
		else if(move == 100)
			moveEast();
		else if(move == 115)
			moveSouth();
		else if(move == ESC){
			system("cls");
			exitGame();
			return;
		}
	}
}
int isSafeCrosshair(int x ,int y)
{
	if(x > 0 && x + 4 < BOARDFPS_WIDTH && y > 0 && y + 4 < BOARDFPS_HEIGHT )
		return 1;
	return 0;
}
void showFPSStatus(int ammo,int stock)
{
	if(ammo == 0){
		gotoxy(86,9);
		printf("\033[0m");
		printf("Empty Ammo!");
	}
	if(ammo <= 5)
		printf("\033[0;31m");
	else
		printf("\033[0;32m");
	gotoxy(11,18);
	printf("Ammo : %d",ammo);
	if(player.health <=20)
			printf("\033[0;31m");
	else
		printf("\033[0;32m");
	gotoxy(11,19);
	printf("Hp : %d",player.health);
	
	printf("\033[0m");
	gotoxy(37,18);
	printf("Press q for exit");
	gotoxy(37,19);
	printf("Press r for reload, your stock is : %d",stock);
	gotoxy(26,21);
	printf("Press[Enter] to attack");
	gotoxy(26,22);
	printf("Enemy Count: %d",countEnemy);
}
int randGenerator(int x,int n)
{
	int randData;
	randData = rand() % n + x;
	return randData;
}
void addEnemy()
{
	for(int i = 0 ; i < 5 ; i ++)
	{
		char buff[5];
		int data = i + 1;
		itoa(data,buff,10);
		srand(time(0));
		strcpy(enemy[i].name,"EN00");
		enemy[i].health = 100;
		enemy[i].dead = 0;
		strcat(enemy[i].name,buff);
		do{
			enemy[i].x = randGenerator(1,BOARDFPS_WIDTH - 2);
			enemy[i].y = randGenerator(1,BOARDFPS_HEIGHT - 2);
		}while(fpsMap[enemy[i].y][enemy[i].x] == 'E');
		fpsMap[enemy[i].y][enemy[i].x] = 'E';
		indexEnemy ++;
		countEnemy++;
	}
}
void showEnemyStatus(int setVisible,int flag,int damageDeal)
{
	if(setVisible == 1)
	{
		gotoxy(86,6);
		printf("\033[0m");
		printf("Enemy %s got %d damage",enemy[flag].name,damageDeal);
		gotoxy(86,7);
		if(enemy[flag].health > 0)
			printf("Now Enemy Hp is %d",enemy[flag].health);
		else
		{
			printf("Now Enemy %s is dead",enemy[flag].name);
		}	
	}
}
void playerShot(int *flag,int *damageDeal,int *setVisible,int ammo, int stock)
{
	int chanceRun;
	int tempX;
	int tempY;
	srand(time(NULL));
	for(int i = crosshair.y ; i < crosshair.y + 4 ; i ++)
	{
		for(int j = crosshair.x ; j < crosshair.x + 4 ; j ++)
		{
			if(fpsMap[i][j] == 'E')
			{
				for(int k = 0 ; k < indexEnemy ; k ++)
				{
					if(enemy[k].x == j && enemy[k].y == i)
					{
						*flag = k;
					}
				}
				chanceRun = randGenerator(1,10);
				if(chanceRun % 10 != 0)
				{
					*setVisible = 1;
					*damageDeal = randGenerator(0,weapon[user[flagUser].weaponID].damage );
					enemy[*flag].health -= *damageDeal;
					if(enemy[*flag].health <= 0){
						enemy[*flag].dead = 1;
						fpsMap[enemy[*flag].y][enemy[*flag].x] = 'x';
						countEnemy --;
					}
				}
				else
				{
					do{
						tempX = randGenerator(1,BOARDFPS_WIDTH - 2);
						tempY = randGenerator(1,BOARDFPS_HEIGHT - 2);
					}while(fpsMap[tempY][tempX] == 'E' || fpsMap[tempY][tempX] == 'x' || (tempX < crosshair.x + 4 && tempX > crosshair.x && tempY > crosshair.y && tempY < crosshair.y + 4));
					enemyAnimation(tempX,tempY,&*flag,ammo,stock);
				}
					
			}
		}
	}
}
void enemyAnimation(int tempX,int tempY,int *flag,int ammo,int stock)
{
	while(enemy[*flag].x > crosshair.x && enemy[*flag].x < crosshair.x + 4 && enemy[*flag].y > crosshair.y && enemy[*flag].y < crosshair.y + 4){
		space(0);
		renderFPSUpdate();
		showFPSStatus(ammo,stock);
		if(enemy[*flag].x < tempX && (fpsMap[enemy[*flag].y][enemy[*flag].x - 1] != 'E' && fpsMap[enemy[*flag].y][enemy[*flag].x + 1] != 'x'))
		{
			fpsMap[enemy[*flag].y][enemy[*flag].x + 1] = 'E';
			fpsMap[enemy[*flag].y][enemy[*flag].x] = ' ';
			enemy[*flag].x ++;
		}
		else if(enemy[*flag].y > tempY && (fpsMap[enemy[*flag].y][enemy[*flag].x - 1] != 'E' && fpsMap[enemy[*flag].y - 1][enemy[*flag].x] != 'x'))
		{
			fpsMap[enemy[*flag].y - 1][enemy[*flag].x] = 'E';
			fpsMap[enemy[*flag].y][enemy[*flag].x] = ' ';
			enemy[*flag].y --;
		}
		else if(enemy[*flag].x > tempX && (fpsMap[enemy[*flag].y][enemy[*flag].x - 1] != 'E' && fpsMap[enemy[*flag].y][enemy[*flag].x - 1] != 'x'))
		{
			fpsMap[enemy[*flag].y][enemy[*flag].x - 1] = 'E';
			fpsMap[enemy[*flag].y][enemy[*flag].x] = ' ';
			enemy[*flag].x --;
		}
		else if(enemy[*flag].y < tempY && (fpsMap[enemy[*flag].y][enemy[*flag].x - 1] != 'E' && fpsMap[enemy[*flag].y + 1][enemy[*flag].x] != 'x'))
		{
			fpsMap[enemy[*flag].y + 1][enemy[*flag].x] = 'E';
			fpsMap[enemy[*flag].y][enemy[*flag].x] = ' ';
			enemy[*flag].y ++;
		}
	}
	fpsMap[enemy[*flag].y][enemy[*flag].x] = ' ';
	enemy[*flag].x = tempX;
	enemy[*flag].y = tempY;
	fpsMap[enemy[*flag].y][enemy[*flag].x] = 'E';
}
void gameplayFPS()
{
	int turn = 0;
	int flag;
	int damageDeal;
	int scoreRandom;
	int setVisible = 0;
	int ammo = 25;
	int stock = 5;
	do{
		if(player.health > 0){
			system("cls");
			char ch;
			renderFPSUpdate();
			showFPSStatus(ammo,stock);
			showEnemyStatus(setVisible,flag,damageDeal);
			if(turn % 3 == 0 && turn != 0){
				turn = 0;
				getDamage();
			}
			ch = getch();
			if(ch == 119){
				if(isSafeCrosshair(crosshair.x, crosshair.y - 1) == 1){
					crosshair.y --;
					turn ++;
				}
				setVisible = 0;
			}
			else if(ch == 115){
				if(isSafeCrosshair(crosshair.x , crosshair.y + 1) == 1){
					crosshair.y ++;
					turn ++;
				}
				setVisible = 0;
			}
			else if(ch == 100){
				if(isSafeCrosshair(crosshair.x + 1, crosshair.y) == 1){
					crosshair.x ++;
					turn ++;
				}
				setVisible = 0;
			}
			else if(ch == 97){
				if(isSafeCrosshair(crosshair.x - 1, crosshair.y) == 1)	{
					crosshair.x --;
					turn ++;
				}
				setVisible = 0;
			}
			else if(ch == 114){
				if(stock > 0){
					ammo = 25;
					stock --;
				}
				setVisible = 0;
			}
			else if(ch == ENTER)
			{
				if(ammo > 0)
				{
					playerShot(&flag,&damageDeal,&setVisible,ammo,stock);
					ammo --;
				}
			}
			else if(ch == 113){
				return;
			}
		}
		else{
			player.health = 0;
			space(20);
			printf("\t\t\tYOU LOSE!!");
			scanf("[^\n]");
			getchar();
			return;
		}
	}while(countEnemy > 0);
	//win
	srand(time(NULL));
	scoreRandom = randGenerator(1,100);
	space(20);
	printf("\t\t\tYOU WIN!, you earned %d points",scoreRandom);
	user[flagUser].score += scoreRandom;
	return;
}
void getDamage()
{
	int chance;
	int takeDamage;
	srand(time(NULL));
	chance = randGenerator(0,2);
	if(chance == 1){
		takeDamage = randGenerator(1,10);
		printf("\033[0;31m");
		gotoxy(0,21);
		printf("You got Damage! %d from enemy",takeDamage);
		player.health -= takeDamage;
	}
}
void renderFPSUpdate()
{
	for(int i = 0 ; i < 15 ;i ++)
	{
		for(int j = 0 ; j < 40 ; j ++)
		{
			if(i < crosshair.y + 4 && i >= crosshair.y && j < crosshair.x + 4 && j >= crosshair.x)
			{
				if(fpsMap[i][j] == 'E'){
					printf("\033[0;34m");
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_GREEN);	
					printf("%c",2);
					printf("\033[0;32m");
					printf("%c",219);
				}
				else if(fpsMap[i][j] == 'x')
				{
					printf("\033[0;34m");
						SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_GREEN);	
					printf("x");
					printf("\033[0;32m");
					printf("%c",219);
				}
				else{
					printf("\033[0;32m");
					printf("%c%c",219,219);
				}
			}
			else if(fpsMap[i][j] == '#')
			{
				printf("\033[0;34m");	
				printf("%c%c",186,186);
			}
			else
				printf("  ");
		}
		printf("\n");
	}
}
void userList()
{
	char buffer[1024];
	while(!feof(userPtr))
	{
		fscanf(userPtr,"%d%*c%[^#]%*c%[^#]%*c%d%*c%d\n",&user[indexUser].id,user[indexUser].username,user[indexUser].password,&user[indexUser].weaponID,&user[indexUser].score);
		strcpy(user[indexUser].password,decryptedCaesar(user[indexUser].password));
		indexUser ++;
	}
}
int checkUser(char name[],char password[])
{
	for(int i = 0 ; i < indexUser ; i ++)
	{
		if(strcmp(user[i].username,name) == 0)
		{
			if(strcmp(user[i].password,password) == 0){
				flagUser = i;
				return 0;
			}
			else 
				return -1;
		}
	}	
	return -1;
}
void loginUser()
{
	char existingUsername[100];
	char existingPassword[100];
	int valid;
	do{
		valid = 0;
		char inputPassword;
		int index = 0;
		do{
			space(10);
			printf("\t\t\t\t\tHello, let me know who are you?\n\t\t\t\t\tUsername [Min length 5 chars]: ");
			scanf("%s",existingUsername);
		}while(strlen(existingUsername) < 5);
		space(10);
		printf("\t\t Password: ");
		while(1)
		{
			inputPassword = getch();
			if(inputPassword == ENTER)
			{
				existingPassword[index ++] = '\0';
				break;
			}
			else if(inputPassword == BACKSPACE)
			{
				if(index > 0)
				{
					index --;
					printf("\b \b");
				}
			}
			else{
				existingPassword[index ++] = inputPassword;
				printf("* \b");
			}
		}
			getchar();
		if(checkUser(existingUsername,existingPassword) == -1)
		{
			valid = 0;
			printf("\n\n\t\t Wrong Account !");
			scanf("[^\n]");			
			getchar();		
		}
		else
			valid = 1;
	}while(valid == 0);
	printf("\n\n\t\t Welcome!!");	
	scanf("[^\n]");
	getchar();
}
char *decryptedCaesar(char newPassword[])
{
	int index = 0;
	int flag;
	char uniqueWord[100];
	//65 - 90 //97 - 122 //48-57
	for(int i = 65 ; i <= 90 ; i ++)
		uniqueWord[index++] = i;
	for(int i = 97 ; i <= 122 ; i ++)
		uniqueWord[index++] = i;
	for(int i = 49 ; i <= 57 ; i ++)
		uniqueWord[index ++] = i;
	uniqueWord[index ++] = 48;
	
	for(int i = 0 ; i < strlen(newPassword); i ++)
	{
		if(isdigit(newPassword[i]) || isalpha(newPassword[i]))
		{
			//shifting
			for(int j = 0 ; j < index ; j ++)
			{
				if(uniqueWord[j] == newPassword[i])
				{
					flag = j;
					break;
				}
			}
			flag = flag - 3;
			while(flag < 0){
				flag += 3;
			}
			newPassword[i] = uniqueWord[flag];
		}
	}
	return newPassword;
}
char *encryptedCaesar(char newPassword[])
{
	int index = 0;
	int flag;
	char uniqueWord[100];
	//65 - 90 //97 - 122 //48-57
	for(int i = 65 ; i <= 90 ; i ++)
		uniqueWord[index++] = i;
	for(int i = 97 ; i <= 122 ; i ++)
		uniqueWord[index++] = i;
	for(int i = 49 ; i <= 57 ; i ++)
		uniqueWord[index ++] = i;
	uniqueWord[index ++] = 48;
	
	for(int i = 0 ; i < strlen(newPassword); i ++)
	{
		if(isdigit(newPassword[i]) || isalpha(newPassword[i]))
		{
			//shifting
			for(int j = 0 ; j < index ; j ++)
			{
				if(uniqueWord[j] == newPassword[i])
				{
					flag = j;
					break;
				}
			}
			flag = flag +3;
			while(flag > index)
				flag -= 3;
			newPassword[i] = uniqueWord[flag];
		}
	}
	return newPassword;
	
}
void splashScreen()
{
	system("cls");
	char title1[][160] = 
	{
		".______     _______.____    ____  ______  __    __    ______   .______      ___      ________   ________ \n",
	  	"|   _  \\   /       |\\   \\  /   / /      ||  |  |  |  /  __  \\  |   _  \\    /   \\    |       /  |       / \n",
		"|  |_)  | |   (----` \\   \\/   / |  ,----'|  |__|  | |  |  |  | |  |_)  |  /  ^  \\   `---/  /   `---/  / \n",
		"|   ___/   \\   \\      \\_    _/  |  |     |   __   | |  |  |  | |   ___/  /  /_\\  \\     /  /       /  / \n",
		"|  |   .----)   |       |  |    |  `----.|  |  |  | |  `--'  | |  |     /  _____  \\   /  /----.  /  /----.\n",
		"| _|   |_______/        |__|     \\______||__|  |__|  \\______/  | _|    /__/     \\__\\ /________| /________|\n"					
	};
	for(int i = 0 ; i < 6; i ++)
	{
		printf("\033[0;31m");
		printf("%s",title1[i]);
		sleep(51000000);
	}
	printf("\033[0m");
}
void registerNewPlayer()
{
	char newUsername[100];char newPassword[100];
	char inputPassword;
	int index = 0;
	do{
		space(10);
		printf("\t\t\t\t\tHello, let me know who are you?\n\t\t\t\t\tUsername [Min length 5 chars]: ");
		scanf("%s",newUsername);
		getchar();
	}while(strlen(newUsername) < 5);
	space(10);
	printf("\t\t Password: ");
	while(1)
	{
		inputPassword = getch();
		if(inputPassword == ENTER)
		{
			newPassword[index ++] = '\0';
			break;
		}
		else if(inputPassword == BACKSPACE)
		{
			if(index > 0)
			{
				index --;
				printf("\b \b");
			}
		}
		else{
			newPassword[index ++] = inputPassword;
			printf("* \b");
		}
	}
	strcpy(user[indexUser].password,newPassword);
	strcpy(user[indexUser].username,newUsername);
	user[indexUser].score = 0;
	user[indexUser].weaponID = 0;
	indexUser ++;
	printf("\n\n\t\t Success !!\n");
	scanf("[^\n]");
	getchar();
}
void space(int x)
{
	system("cls");
	for(int i = 0 ; i < x ; i ++)
		printf("\n");
}
void sleep(int time)
{
	for(int i = 0 ; i < time ; i ++);
}
void gotoxy(int x , int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
